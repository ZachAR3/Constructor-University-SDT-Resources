/*
BERING TAFA
*/
#include <iostream>
#include <stdexcept>
using namespace std;
double division(double a, double b){
    if( b == 0 ) throw logic_error("Division by zero not allowed!");
    return a/b;
}
int main ()
{
    double x,y;
    cin>>x>>y;
    try {
        cout<<division(x, y)<<endl;
    }catch (logic_error& e) {
        cerr << e.what() << endl;
    }
    return 0;
}
