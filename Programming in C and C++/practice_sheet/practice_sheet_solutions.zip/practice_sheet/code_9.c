/*
BERING TAFA
*/
#include <stdio.h>
int main(){
    int n;
    char ch;
    scanf("%d",&n);
    getchar();
    scanf("%c",&ch);
    for(int i=1; i<=n; i++){
        for(int j=0; j<i; j++){
            printf("%c",ch);
        }
        printf("\n");
    }
    return 0;
}
