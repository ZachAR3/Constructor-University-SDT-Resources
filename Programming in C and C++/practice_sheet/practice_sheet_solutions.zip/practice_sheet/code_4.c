/*
BERING TAFA
*/
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
bool password_checker(char* pass){
    int n = strlen(pass);
    int digits = 0;
    if (n<8) return false;
    for(int i=0; i<n; i++){
        digits = (pass[i]>='0'&&pass[i]<='9'?digits+1:digits+0);
    }
    if (digits<3) return false;
    return true;
}
int main(){
    char s[100];
    scanf("%s",s);
    printf("%d",password_checker(s));
    return 0;
}
