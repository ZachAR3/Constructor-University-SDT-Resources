/*
BERING TAFA
*/
#include <iostream>
#include <cmath>
#include <limits>
using namespace std;
class Complex {
    private:
        float real;  // real part
        float imag;  // imaginary part
    public:
        Complex();
        Complex(float, float = 0);
        double magnitude();
        void print();
        friend std::ostream& operator << (std::ostream &os, const Complex &a);
        bool operator >(const Complex &a);
        bool operator <(const Complex &a);

};
Complex::Complex(float a, float b){
    real=a;
    imag=b;
}
void Complex::print() {
    if (imag)
        cout << noshowpos << real << showpos << imag << "i" << endl;
    else
        cout << noshowpos << real << endl;
}
ostream& operator <<(std::ostream &os, const Complex &a){
    if (a.imag)
        os << noshowpos << a.real << showpos << a.imag<<"i"<<endl;
    else
        os << noshowpos << a.real << endl;
    return os;
}
bool Complex::operator > (const Complex &a){
    if (sqrt(real*real+imag*imag)>sqrt(a.real*a.real+a.imag*a.imag)) return true;
    return false;
}
bool Complex::operator < (const Complex &a){
    if (sqrt(real*real+imag*imag)<sqrt(a.real*a.real+a.imag*a.imag)) return true;
    return false;
}
int main(){
    Complex a(5,2);
    Complex b(6,8);
    cout<<a;
    cout<<b;
    cout<<"a>b? "<<(a>b?"YES":"NO")<<endl;
    cout<<"a<b? "<<(a<b?"YES":"NO")<<endl;
    return 0;
}
