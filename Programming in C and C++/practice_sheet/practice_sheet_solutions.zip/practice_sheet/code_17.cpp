/*
BERING TAFA
*/
#include <cstring>
#include <iostream>
using namespace std;
class Book {
    private:
        char* title;
        int pages;
    public:
        Book(const Book&);
        Book(const char * t, int p);
        Book();
        // ...
        // setter and getter methods omitted
        void print(){
            cout<<title<<" -> "<<pages<<endl;
        }
        ~Book(){
            delete[] title;
        }
};
Book::Book(const Book& a){
    title=new char[30];
    strcpy(title,a.title);
    pages=a.pages;
    //title = a.title -> default copy constructor => pointing to the same loaction
    //pages = a.pages -> default copy constructor
}
Book::Book(const char* t, int p){
    title=new char[30];
    strcpy(title, t);
    pages=p;
}
int main(){
    Book a("programming",100);
    a.print();
    Book b = a;
    b.print();
    return 0;
}
