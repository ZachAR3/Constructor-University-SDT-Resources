/*
BERING TAFA
*/
#include <stdio.h>
#include <assert.h>
int main(){
    FILE* p=fopen("squares.txt", "w");
    assert(p!=NULL);
    int n;
    scanf("%d",&n);
    int a[n];
    for(int i=0; i<n; i++){
        scanf("%d",&a[i]);
    }
    for(int i=n-1; i>=0; i--){
        fprintf(p,"%d %d\n", a[i], a[i]*a[i]);
    }
    fclose(p);
    return 0;
}
