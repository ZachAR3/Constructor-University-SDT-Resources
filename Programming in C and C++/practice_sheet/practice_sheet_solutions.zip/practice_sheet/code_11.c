/*
BERING TAFA
*/
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
struct node {
    char str[20];
    struct node * next;
};
struct node* insertBegin(struct node *head, char str[]){
    struct node* new_elem = malloc(sizeof(struct node));
    assert(new_elem);
    strcpy(new_elem->str,str);
    new_elem->next=head;
    return new_elem;
}
void printList(struct node *head){
    struct node* cursor = head;
    while (cursor!=NULL) {
        printf("%s ",cursor->str);
        cursor=cursor->next;
    }
    printf("\n");
}
int main(){
    struct node* head=NULL;
    int n;
    scanf("%d",&n);
    for(int i=0; i<n; i++){
        char new_elem[100];
        scanf("%s",new_elem);
        head = insertBegin(head, new_elem);
        printList(head);
    }
    struct node* cursor=head;
    struct node* temp=head;
    while (cursor!=NULL) {
        temp=temp->next;
        free(cursor);
        cursor=temp;
    }
    return 0;
}
