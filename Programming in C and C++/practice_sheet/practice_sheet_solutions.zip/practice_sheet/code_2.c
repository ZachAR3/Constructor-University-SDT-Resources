/*
BERING TAFA
*/
#include <stdio.h>
int main(){
    double a;
    scanf("%lf",&a);
    float b;
    scanf("%f",&b);
    int c;
    scanf("%d",&c);
    double result = a*b*c;
    printf("%lf\n",result);
    double* r_ptr = &result;
    *r_ptr +=5;
    printf("%lf\n",result);
    printf("%lf\n",*r_ptr);
    return 0;
}
