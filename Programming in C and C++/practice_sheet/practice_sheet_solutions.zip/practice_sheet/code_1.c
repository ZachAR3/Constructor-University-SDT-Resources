/*
BERING TAFA
*/
#include <stdio.h>
int main(){
    int n;
    scanf("%d",&n);
    // => after 26 it will print other characters that 
    //are not in the alphabet
    int a='A';
    for(int i=1; i<=n; i++){
        for(int j=0; j<i; j++){
            printf("%c",a+j);
        }
        printf("\n");
    }
    return 0;
}
