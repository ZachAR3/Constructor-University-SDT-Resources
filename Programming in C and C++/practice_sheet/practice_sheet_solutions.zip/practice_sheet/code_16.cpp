/*
BERING TAFA
*/
#include <iostream>
#include <utility>
using namespace std;
class Car{
    private:
        string name;
        string model_name;
    public:
        Car(){
            name="bering";
            model_name="tafa";
        }
        Car(string a, string b){
            name=a;
            model_name=b;
        }
        ~Car(){
        }
        void set_model_name(string a){
            model_name=a;
        }
        string get_name(){
            return name;
        }
        string get_model_name(){
            return model_name;
        }
        void print(){
            cout<<name<<" -> "<<model_name<<endl;
        }
};
class Taxi:public Car{
    private:
        int pasangers;
    public:
        Taxi():Car(){
            pasangers=0;
        }
        Taxi(string a, string b, int c):Car(a,b){
            pasangers=c;
        }
        void print(){
            cout<<this->get_name()<<" "<<this->get_model_name()<<" "<<pasangers<<endl;
        }
        ~Taxi(){
        }
};
int main(){
    Car a;
    Car b("Mercedes-Benz","Mercedes-Benz SLS AMG");
    b.set_model_name("Mercedes-Benz EQS");
    Taxi c("Taxi","Honda",5);
    c.print();
    return 0;
}
