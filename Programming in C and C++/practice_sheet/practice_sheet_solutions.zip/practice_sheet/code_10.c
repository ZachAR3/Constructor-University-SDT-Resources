/*
BERING TAFA
*/
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
void print_matrix(int **A, int rows, int cols){
    for(int i=0; i<rows; i++){
        for(int j=0; j<cols; j++){
            printf("%d",A[i][j]);
        }
        printf("\n");
    }
}
int main(){
    int r,c;
    FILE* p = fopen("matrix.dat","r");
    assert(p!=NULL);
    fscanf(p, "%d",&r);
    fscanf(p, "%d",&c);
    int** a = malloc(sizeof(int*)*r);
    assert(a!=NULL);
    for(int i=0; i<r; i++){
        a[i]=malloc(sizeof(int)*c);
        assert(a[i]!=NULL);
    }
    for(int i=0; i<r; i++){
        for(int j=0; j<c; j++){
            a[i][j]=0;
        }
    }
    int x;
    int index=0;
    int index_1,index_2,elem;
    while (fscanf(p,"%d",&x)!=EOF){
        if (index%3==0) index_1=x;
        if (index%3==1) index_2=x;
        if (index%3==2) elem=x, a[index_1-1][index_2-1]=elem;
        index++;
    }
    //can be solved even by taking row by row and extracting
    //the data from that string
    print_matrix(a,r,c);
    for(int i=0; i<r; i++){
        free(a[i]);
    }
    free(a);
    fclose(p);
    return 0;
}
