/*
BERING TAFA
*/
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
typedef struct river {
    char name[40];
    int length;
    int drainage_area;
}river;
int comp(const void* a, const void* b){
    river* x = (river*)a;
    river* y = (river*)b;
    return x->length-y->length;
}
int main(){
    river a[30];
    FILE* p = fopen("data.txt","r");
    assert(p!=NULL);
    int index=0;
    while (1) {
        if (index%3==0 && fscanf(p,"%s",a[index/3].name)==EOF) break;
        if (index%3==1 && fscanf(p,"%d",&a[index/3].length)==EOF) break;
        if (index%3==2 && fscanf(p,"%d",&a[index/3].drainage_area)==EOF) break;
        index++;
    }
    //you can take the input line by line too
    qsort(a,(index-1)/3+1,sizeof(river),comp);
    for(int i=0; i<=(index-1)/3; i++){
        printf("%s %d %d\n",a[i].name,a[i].length,a[i].drainage_area);
    }
    fclose(p);
    return 0;
}
