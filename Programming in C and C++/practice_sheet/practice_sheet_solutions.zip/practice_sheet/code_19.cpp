/*
BERING TAFA
*/
#include <iostream>
using namespace std;
class worker{
    private:
        int id;
        string name;
    public:
        worker(){
            id=0;
            name="unknown";
        }
        worker(int a,string b){
            id=a;
            name=b;
        }
        friend std::ostream& operator << (std::ostream &os, const worker &a);
};
ostream& operator <<(std::ostream &os, const worker &a){
    os<<a.id<<" -> "<<a.name<<endl;
    return os;
}
int main() {
    worker a(234, "John McEnroe");
    worker b(324, "Jack Nicholson");
    cout << a << b;
    return 0;
}
