/*
BERING TAFA
*/
#include <iostream>
using namespace std;
class Person {
    protected:
        string name;
        int age;
    public:
        Person() {
            cout << "Person destructor" << endl;
        } };
class Student : public virtual Person {
    protected:
        long int matr_nr;
    public:
        Student() {
            cout << "Student destructor" << endl;
        } };
class Faculty : public virtual Person {
    protected:
        int employ_nr;
    public:
        Faculty() {
            cout << "Faculty destructor" << endl;
        } };
class TA : public Student, public Faculty {
    private:
        string course_nr;
    public:
        TA() {
            course_nr = "CH_230_A";
        }
        TA(const TA &obj) {
            this->name = obj.name;
            this->age = obj.age;
            this->matr_nr = obj.matr_nr;
            this->employ_nr = obj.employ_nr;
            this -> course_nr = obj.course_nr;
        }
        ~TA() {
            cout << "TA destructor" << endl;
        }
        friend void print(const TA a);
};
void print(const TA a) {
    cout << a.course_nr << endl;
}
int main() {
    TA ta1;
    TA ta2(ta1);
    print(ta2);
    return 0;
}
/*
Person destructor
Student destructor
Faculty destructor
Person destructor
Student destructor
Faculty destructor
Person destructor
Student destructor
Faculty destructor
CH_230_A
TA destructor
TA destructor
TA destructor
======
explenation:
TA ta1:
Person destructor
Student destructor
Faculty destructor
Ta ta2:
Person destructor
Student destructor
Faculty destructor
const TA a:
Person destructor
Student destructor
Faculty destructor
CH_230_A
const TA a;
TA destructor
TA ta2:
TA destructor
TA ta1:
TA destructor
*/
