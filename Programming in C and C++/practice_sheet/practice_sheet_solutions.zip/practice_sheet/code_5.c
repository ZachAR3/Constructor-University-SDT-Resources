/*
BERING TAFA
*/
#include <stdio.h>
#include <stdbool.h>
bool odd(unsigned char data){
    return data&1;
}
int main(){
    printf("%d",odd('A'));
    printf("%d",odd('B'));
    printf("%d",odd('C'));
    printf("%d",odd('D'));
    printf("%d",odd('E'));
    return 0;
}
